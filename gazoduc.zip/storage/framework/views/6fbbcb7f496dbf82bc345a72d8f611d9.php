<!DOCTYPE html>
<html>
<head>
    <title>Historique des Dépotages</title>
    <meta charset="utf-8">
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 10px;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
            color: #333;
            text-transform: uppercase;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        .header h1 {
            margin: 0;
            font-size: 20px;
            color: #333;
        }
        .header p {
            margin: 5px 0;
            font-size: 12px;
            color: #666;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 15px;
            border-top: 1px solid #eee;
            font-size: 9px;
            color: #888;
        }
        .text-right {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
        .summary-box {
            background-color: #f9f9f9;
            border: 1px solid #eee;
            padding: 10px;
            margin-bottom: 20px;
            font-size: 11px;
            line-height: 1.6;
        }
        /* Styles pour les dépotages supprimés */
        .deleted-row {
            background-color: #ffeaea; /* Arrière-plan rouge clair pour indiquer la suppression */
            color: #8b0000; /* Texte rouge foncé */
            text-decoration: line-through; /* Ligne barrée sur le texte */
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Historique des Depotages</h1>
        <p>Genere le: <?php echo e(\Carbon\Carbon::now()->format('d/m/Y H:i:s')); ?></p>
    </div>

    <div class="summary-box">
        <p>
            <strong>Periode:</strong> Du **<?php echo e(\Carbon\Carbon::parse($start_date)->format('d/m/Y')); ?>** au **<?php echo e(\Carbon\Carbon::parse($end_date)->format('d/m/Y')); ?>**
        </p>
        <p>
            <strong>Agence:</strong>
            <?php if($selectedAgency): ?>
                <?php echo e($selectedAgency->name); ?>

            <?php else: ?>
                Toutes les agences
            <?php endif; ?>
        </p>
        <p>
            <strong>Nombre total de depotages:</strong> <?php echo e($depotages->count()); ?>

            <?php if($isWithDeleted): ?>
                (dont <?php echo e($depotages->whereNotNull('deleted_at')->count()); ?> supprimes)
            <?php endif; ?>
        </p>
        <p>
            <strong>Quantité totale depotee:</strong> <?php echo e(number_format($depotages->sum('quantity'), 2, ',', ' ')); ?> L
        </p>
    </div>

    <table>
        <thead>
            <tr>
                <th class="text-center">ID</th>
                <th>Date Depotage</th>
                <th>Citerne Mobile</th>
                <th>Citerne Fixe</th>
                <th>Article</th>
                <th class="text-right">Quantite (L)</th>
                <th>Agence</th>
                <th>BL Numero</th>
                <th>Enregistre par</th>
                <th>Cree le</th>
                <?php if($isWithDeleted): ?>
                    <th>Supprime le</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $depotages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depotage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="<?php echo e($depotage->deleted_at ? 'deleted-row' : ''); ?>">
                    <td class="text-center"><?php echo e($depotage->id); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($depotage->depotage_date)->format('d/m/Y')); ?></td>
                    <td><?php echo e($depotage->citerne_mobile->licence_plate ?? 'N/A'); ?></td>
                    <td><?php echo e($depotage->citerne_fixe->name ?? 'N/A'); ?></td>
                    <td><?php echo e($depotage->article->name ?? 'N/A'); ?></td>
                    <td class="text-right"><?php echo e(number_format($depotage->quantity, 2, ',', ' ')); ?></td>
                    <td><?php echo e($depotage->agency->name ?? 'N/A'); ?></td>
                    <td><?php echo e($depotage->bl_number ?? '—'); ?></td>
                    <td><?php echo e($depotage->user->first_name ?? 'N/A'); ?> <?php echo e($depotage->user->last_name ?? ''); ?></td>
                    <td><?php echo e($depotage->created_at->format('d/m/Y H:i')); ?></td>
                    <?php if($isWithDeleted): ?>
                        <td><?php echo e($depotage->deleted_at ? \Carbon\Carbon::parse($depotage->deleted_at)->format('d/m/Y H:i') : '—'); ?></td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="<?php echo e($isWithDeleted ? '11' : '10'); ?>" class="text-center">Aucun depotage trouve pour les criteres specifies, monsieur.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="footer">
        <p>Rapport genere par votre systeme de gestion. &copy; <?php echo e(date('Y')); ?></p>
    </div>
</body>
</html>
<?php /**PATH C:\Users\blacktrojan\Documents\Lab\gazoduc\resources\views/PDF/DepotagePDFView.blade.php ENDPATH**/ ?>