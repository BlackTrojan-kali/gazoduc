<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Paiements de Carburant</title>
    <style>
        body { font-family: sans-serif; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #000; padding: 8px; text-align: left; }
        th { background-color: #f0f0f0; }
    </style>
</head>
<body>
    <h2>Liste des paiements de carburant</h2>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Agence</th>
                <th>Client</th>
                <th>Banque</th>
                <th>Montant</th>
                <th>Type</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($p->id); ?></td>
                    <td><?php echo e($p->agency->name ?? ''); ?></td>
                    <td><?php echo e($p->client->name ?? ''); ?></td>
                    <td><?php echo e($p->bank->name ?? ''); ?></td>
                    <td><?php echo e(number_format($p->amout, 2, ',', ' ')); ?> XAF</td>
                    <td><?php echo e($p->type); ?></td>
                    <td><?php echo e($p->created_at->format('d/m/Y')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\blacktrojan\Documents\Lab\gazoduc\resources\views/PDF/fuel_payments.blade.php ENDPATH**/ ?>