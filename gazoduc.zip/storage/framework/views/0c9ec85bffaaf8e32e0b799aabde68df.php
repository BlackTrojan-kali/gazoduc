<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($reportTitle); ?></title>
    <style>
        /* Styles CSS pour le PDF */
        body { font-family: sans-serif; font-size: 10px; }
        h1 { font-size: 18px; text-align: center; }
        .header { margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 6px; text-align: left; }
        th { background-color: #f2f2f2; }
        /* Style spécifique pour la ligne de total */
        tfoot td {
            background-color: #e0e0e0;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><?php echo e($reportTitle); ?></h1>
        <p><strong>Période:</strong> <?php echo e($period); ?></p>
        <p><strong>Agence:</strong> <?php echo e($filters['agency_name']); ?> | <strong>Carburant:</strong> <?php echo e($filters['article_name']); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Client</th>
                <th>Article</th>
                <th>Qté (L)</th>
                <th>Prix Unitaire</th>
                <th>Total (XOF)</th>
                <th>Agence</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $totalQuantity = 0;
                $totalTotalPrice = 0;
            ?>
            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($sale->id); ?></td>
                <td><?php echo e($sale->client->name ?? 'N/A'); ?></td>
                <td><?php echo e($sale->article->name ?? 'N/A'); ?></td>
                <td><?php echo e(number_format($sale->quantity, 2, ',', ' ')); ?></td>
                <td><?php echo e(number_format($sale->unitPrice, 0, ',', ' ')); ?></td>
                <td><?php echo e(number_format($sale->total_price, 0, ',', ' ')); ?></td>
                <td><?php echo e($sale->agency->name ?? 'N/A'); ?></td>
                <td><?php echo e($sale->created_at->format('d/m/Y H:i')); ?></td>
            </tr>
            <?php
                // Accumulation des totaux
                $totalQuantity += $sale->quantity;
                $totalTotalPrice += $sale->total_price;
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" style="text-align: right; font-weight: bold;">TOTAL DES VENTES:</td>
                <td style="text-align: left;"><?php echo e(number_format($totalQuantity, 2, ',', ' ')); ?></td>
                <td></td> 
                <td style="text-align: left;"><?php echo e(number_format($totalTotalPrice, 0, ',', ' ')); ?></td>
                <td colspan="2"></td> 
            </tr>
        </tfoot>
    </table>
</body>
</html>
<?php /**PATH C:\Users\blacktrojan\Documents\Lab\gazoduc\resources\views/PDF/fuel_sales_pdf.blade.php ENDPATH**/ ?>