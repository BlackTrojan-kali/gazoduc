

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bordereaux de Route par Article</title>
    <style>
        body { font-family: 'Helvetica', sans-serif; font-size: 10px; }
        h1 { text-align: center; color: #333; margin-bottom: 10px; font-size: 16px; }
        h2 { text-align: center; color: #555; margin-bottom: 5px; font-size: 14px; }
        p { text-align: center; margin-bottom: 20px; color: #666; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        .date-range { text-align: center; margin-bottom: 20px; font-style: italic; color: #666; }
        .total-section { margin-top: 20px; text-align: right; font-weight: bold; }
    </style>
</head>
<body>

    <h1>Rapport des Bordereaux de Route</h1>
    <h2>Article: <?php echo e($article->name ?? 'N/A'); ?></h2>
    <?php if($startDate || $endDate): ?>
        <div class="date-range">
            Période du <?php echo e($startDate ? date('d/m/Y', strtotime($startDate)) : 'début'); ?> au <?php echo e($endDate ? date('d/m/Y', strtotime($endDate)) : 'aujourd\'hui'); ?>

        </div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>N° Bordereau</th>
                <th>Véhicule</th>
                <th>Chauffeur</th>
                <th>Départ</th>
                <th>Arrivée</th>
                <th>Quantité</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $filteredRoadbills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item['roadbill']->id); ?></td>
                    <td><?php echo e($item['roadbill']->vehicle->licence_plate ?? 'N/A'); ?></td>
                    <td><?php echo e($item['roadbill']->chauffeur->name ?? 'N/A'); ?></td>
                    <td><?php echo e($item['roadbill']->departure->name ?? 'N/A'); ?></td>
                    <td><?php echo e($item['roadbill']->arrival->name ?? 'N/A'); ?></td>
                    <td><?php echo e($item['article']->pivot->qty); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="total-section">
        Quantité totale pour l'article <?php echo e($article->name ?? 'N/A'); ?>: <?php echo e($totalQuantity); ?>

    </div>

</body>
</html>
<?php /**PATH C:\Users\blacktrojan\Documents\Lab\gazoduc\resources\views/PDF/filtered_roadbills_by_article.blade.php ENDPATH**/ ?>