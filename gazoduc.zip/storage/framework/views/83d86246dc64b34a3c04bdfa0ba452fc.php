<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Facture #<?php echo e($subscription->id); ?></title>
    <style>
        body { font-family: sans-serif; }
        .header { text-align: center; margin-bottom: 30px; }
        .logo { max-width: 150px; }
        .invoice-details { float: right; }
        .company-info { float: left; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .total { text-align: right; font-weight: bold; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="header">
        <img src="<?php echo e(public_path('images/logo-erp.png')); ?>" alt="Logo de l'entreprise" class="logo">
        <h1>Facture</h1>
    </div>

    <div class="company-info">
        <strong>Authentica SARL</strong><br>
        Odza terminus<br>
        620587504<br>
        contact@authentica.com
    </div>

    <div class="invoice-details">
        <strong>Facture #:</strong><?php echo rand(0,999999999999);?><br>
        <strong>Date:</strong> <?php echo e($start); ?> <br> <strong>exp:</strong><?php echo e($newExpirationDate); ?><br>
        <strong>Client:</strong> <?php echo e($entreprise->name); ?>

    </div>
    <div style="clear: both;"></div>

    <table>
        <thead>
            <tr>
                <th>Description</th>
                <th>Quantité</th>
                <th>Prix unitaire</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($licence->name); ?></td>
                <td><?php echo e(count($agencies)); ?></td>
                <td><?php echo e($price); ?></td>
                <?php $total =  count($agencies) * $price;?>
                <td><?php echo e($total); ?></td> 
            </tr>
        </tbody>
    </table>

    <div class="total">
        Total : <?php echo e($total); ?> XAF
    </div>
</body>
</html><?php /**PATH C:\Users\blacktrojan\Documents\Lab\gazoduc\resources\views/factures/licencePDFView.blade.php ENDPATH**/ ?>