<!DOCTYPE html>
<html>
<head>
    <title>Historique des Relevés de Citerne</title>
    <meta charset="utf-8"> 
    <style>
        /* Utilisez 'DejaVu Sans' pour la compatibilité avec les caractères spéciaux (accents, € etc.) */
        body { font-family: 'DejaVu Sans', sans-serif; font-size: 10px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .header { text-align: center; margin-bottom: 30px; }
        .footer { text-align: center; margin-top: 30px; font-size: 8px; color: #555; }
        .text-right { text-align: right; } /* Pour aligner les nombres à droite */
        .text-center { text-align: center; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Historique des Releves de Citerne</h1>
        <p>
            Periode : Du **<?php echo e(\Carbon\Carbon::parse(request('start_date'))->format('d/m/Y')); ?>** au **<?php echo e(\Carbon\Carbon::parse(request('end_date'))->format('d/m/Y')); ?>**
            <?php if(request('agency_id')): ?>
                <br>Agence : **<?php echo e(optional($releves->first())->agency->name ?? 'N/A'); ?>**
            <?php else: ?>
                <br>Agence : **Toutes les agences**
            <?php endif; ?>
        </p>
        <p>Genere le: <?php echo e(\Carbon\Carbon::now()->format('d/m/Y H:i')); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Citerne</th>
                <th>Agence</th>
                <th class="text-right">Qte Theorique </th>
                <th class="text-right">Qte Mesuree </th>
                <th class="text-right">Difference </th>
                <th>Date Lecture</th>
                <th>Enregistre par</th>
                <th>Cree le</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $releves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $releve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($releve->id); ?></td>
                    <td><?php echo e($releve->citerne->name ?? 'N/A'); ?></td>
                    <td><?php echo e($releve->agency->name ?? 'N/A'); ?></td>
                    <td class="text-right"><?php echo e(number_format($releve->theorical_quantity, 0, ',', ' ')); ?></td>
                    <td class="text-right"><?php echo e(number_format($releve->measured_quantity, 0, ',', ' ')); ?></td>
                    <td class="text-right"><?php echo e(number_format($releve->difference, 0, ',', ' ')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($releve->reading_date)->format('d/m/Y')); ?></td>
                    <td><?php echo e($releve->user->first_name ?? 'N/A'); ?> <?php echo e($releve->user->last_name ?? ''); ?></td>
                    <td><?php echo e($releve->created_at->format('d/m/Y H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center">Aucun releve trouve pour les criteres specifies.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="footer">
        <p>Rapport genere par votre systeme de gestion de stocks. &copy; <?php echo e(date('Y')); ?></p>
    </div>
</body>
</html><?php /**PATH C:\Users\blacktrojan\Documents\Lab\gazoduc\resources\views/PDF/RelevePDFView.blade.php ENDPATH**/ ?>