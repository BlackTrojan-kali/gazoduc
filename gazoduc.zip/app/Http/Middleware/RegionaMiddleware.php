<?php

namespace App\Http\Middleware;

use App\Models\Role;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class RegionaMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        if(!Auth::user()){
            return redirect("/login")->with("error","not logged in");
        }else{
            if(Auth::user()->role->name !== "controleur"){
               
            return redirect()->route("login")->with("warning","vous n'etes pas authorize a acceder a cette ");
            }
        }

        return $next($request);
    }
}
