<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class isAuthenticatedMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {

        if(!Auth::user()){
            return redirect()->route("login")->with("error","you need to be authenticated");
        }
        if(Auth::user()->archived == 1 ){
            return redirect()->route("login")->with("error","you are banned from the systeme");
        }
        return $next($request);
    }
}
