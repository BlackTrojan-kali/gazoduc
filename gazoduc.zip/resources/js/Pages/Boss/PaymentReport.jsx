import React from 'react';
import { usePage, Head } from '@inertiajs/react';
import CEOLayout from '../../layout/CEOLayout/CEOLayout';

const PaymentReport = () => {
  const { report, year } = usePage().props;

  return (
    <div className="p-6 space-y-6">
      <Head title={`Rapport des versements ${year}`} />
      <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-100">
        Rapport des versements ({year})
      </h1>

      <table className="w-full border text-sm">
        <thead className="bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
          <tr>
            <th className="p-2 border">Mois</th>
            <th className="p-2 border">Type</th>
            <th className="p-2 border">Banque</th>
            <th className="p-2 border">Agence</th>
            <th className="p-2 border text-right">Versements</th>
            <th className="p-2 border text-right">Notes</th>
            <th className="p-2 border text-right">Factures</th>
            <th className="p-2 border text-right">Écart</th>
          </tr>
        </thead>
        <tbody>
          {report.map((r, i) => (
            <tr key={i} className="hover:bg-gray-50 dark:hover:bg-gray-800">
              <td className="border p-2">{new Date(0, r.month - 1).toLocaleString('fr', { month: 'long' })}</td>
              <td className="border p-2">{r.type}</td>
              <td className="border p-2">{r.bank_name}</td>
              <td className="border p-2">{r.agency_name}</td>
              <td className="border p-2 text-right">{r.total_versement?.toLocaleString()}</td>
              <td className="border p-2 text-right">{r.total_notes?.toLocaleString()}</td>
              <td className="border p-2 text-right">{r.total_facture?.toLocaleString()}</td>
              <td
                className={`border p-2 text-right font-semibold ${
                  r.ecart > 0 ? 'text-green-600' : r.ecart < 0 ? 'text-red-600' : 'text-gray-700'
                }`}
              >
                {r.ecart?.toLocaleString()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

PaymentReport.layout = page => <CEOLayout children={page} />;
export default PaymentReport;
